Trabalho feito por Anderson Aparecido do Carmo Frasão
GRR 20204069
para a diciplina Algoritmos e Teoria dos Grafos
do curso de Ciência da Computação 
da Universidade Federal do Paraná
ministrada pelo professor Murilo V. G. da Silva

O objetivo deste trabalho é desenvolver uma biblioteca básica para análise de grafos.
Para isso foi ultilizado a API graphviz

Para melhor entendimento do código foram criadas novas funções além das pré definidas
E além disso também foram declaradas novas estrutura no arquivo grafo.h

para usar a biblioteca use #include "grafo.h"